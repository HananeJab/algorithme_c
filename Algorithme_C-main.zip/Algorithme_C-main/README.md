
## Algorithme et langage C : 

Vous trouvez la documentation sur le lien suivant. 

:label: [Visitez le lien suivant](https://github.com/imanegannaoui/Algorithme_C/wiki)

## Sujets de recherche  : 

* Triangle Pascal : Algorithme + implémentation en C + rapport d'activités.
* Chiffrement RSA : Algorithme + implémentation en C + rapport d'activités.
* Les algorithmes de tri : tri par selection, tri par insertion et tri à bulle, comprendre l'algorithme + rapport d'activités et implémentation en C 
* Algorithme de recherche dans un ensemble : la recherche sequentielle et la recherche dichotomique + compréhension de l'algorithme implémentation en C + rapport d'activités 



