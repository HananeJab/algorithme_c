# Avant propos : 

Le but de ce projet est de mettre en évidence votre capacité d'analyse, de traitement et de gestion du temps en mode agile.


## Recommandations 

* Un repository Github pour l'historique de vos commits journaliers.
* Agile board de vos activités journalieres.
* CodeBlocks ou autre éditeur pour le code.


## Modalités pédagogiques et livrable : 

* Travail individuel 
* Chronogramme de vos taches journalieres 
* Agile board de vos activités durant le projet 
* Repository Github avec un historique des commits 
* User Story Mapping des taches selon la difficulté et la priorité des taches 


## User Stories : 

En cours de préparation......




