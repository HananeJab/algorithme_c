
## Agile workflow: 

Vous trouvez ici un modéle de la gestion d'un projet agile :

:label: [Agile workflow](https://miro.com/welcomeonboard/1WQCBqns00jvY5z4cxqU8iT09CyES8U0i2aILzOn8jbw7NBy3tuLFQ6e8aau9ckI)



